# DeepSeek Runner

`deepseek-runner-linux-x64-musl.bin` 是 AI Studio 的 GitHub Actions 文本执行器。

运行入口固定为：

```text
deepseek-runner-linux-x64-musl.bin run
```

Runner 从受保护环境读取任务身份、OIDC 请求地址和 `DEEPSEEK_API_KEY`。它先领取
canonical body，再核对 SHA-256，随后通过固定 DeepSeek Provider 发起有界 SSE
请求，定期心跳并在完成后回调结果。Key、body、媒体 URL 和结果正文不写入日志。

用户取消由下一次心跳观察；Runner 发送一次有界 `cancel_observed` 回调后停止本地流。
请求超时、断流、截断或未知响应不得自动换键重放。

发布清单同时包含：

- `deepseek-runner.sha256`；
- `deepseek-runner-manifest.json`。

清单绑定源仓提交 SHA、静态目标、Rust 版本、请求/结果 schema 和二进制摘要。
