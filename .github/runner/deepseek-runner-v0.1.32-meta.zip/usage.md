# DeepSeek Runner

`deepseek-runner-linux-x64-musl.bin` 是 AI Studio 的 GitHub Actions 文本执行器。

运行入口固定为下列两个子命令之一：

```text
deepseek-runner-linux-x64-musl.bin run
deepseek-runner-linux-x64-musl.bin probe
```

`run` 从受保护环境读取任务身份、OIDC 请求地址、必填 `DEEPSEEK_BASE_URL` 和
`DEEPSEEK_API_KEY`。它先领取 canonical body，再核对 SHA-256，随后向 Workflow
Secret 指定的 Provider 发起有界 SSE 请求，定期心跳并在完成后回调结果。Key、
body、媒体 URL 和结果正文不写入日志。

用户取消由下一次心跳观察；Runner 发送一次有界 `cancel_observed` 回调后停止本地流。
网络发送错误、429 和 5xx 在同一 execution 内使用有界指数退避，最多总计尝试
4 次；单次请求最多等待 30 秒。取得并验证 2xx SSE 后不再发送新的 POST。流开始后
的断流、截断或未知结果按既有 `acceptance_unknown` 语义失败关闭，不得自动换键
重放。生产 Provider 基址只存在于 Actions Secret，源码和公开 workflow 不保存默认值。

`probe` 只用于文本 Runner 调度链路的独立健康探测。它从
`RUNNER_PROBE_ID` 与 `RUNNER_PROBE_NONCE` 读取受控探针身份，使用固定
`ai-studio-deepseek-runner` OIDC audience 调用 claim 和 result 接口。该模式不需要
`DEEPSEEK_API_KEY`，不读取 canonical body，不访问 Provider，也不写用户、媒体或任务
数据；成功后只回报固定脱敏 `result_sha256`。配置或控制面错误只输出稳定类别。

发布清单同时包含：

- `deepseek-runner.sha256`；
- `deepseek-runner-manifest.json`。

清单绑定源仓提交 SHA、静态目标、Rust 版本、请求/结果 schema 和二进制摘要。
